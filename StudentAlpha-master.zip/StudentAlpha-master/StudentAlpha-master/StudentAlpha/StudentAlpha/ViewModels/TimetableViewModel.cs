﻿using static StudentAlpha.App;
using Newtonsoft.Json;
using StudentAlpha.Services;
using StudentAlpha_Codes.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Data;

namespace StudentAlpha.ViewModels
{
    public class TimetableViewModel: INotifyPropertyChanged
    {
        #region Properties
        public ObservableCollection<TimetableData> Timetable { get; set; }

        private TimetableData _Event;
        public TimetableData Event
        {
            get {return _Event; }
            set { Set(ref _Event, value); }
        }

        #region AddPurpose
        public string Subject_Input { get; set; }
        public string Description_Input { get; set; }
        public string Lecture_Input { get; set; }
        public DateTime StartDateTime_Input { get; set; } = DateTime.Now;
        public DateTime EndDateTime_Input { get; set; } = DateTime.Now;
        #endregion
        #endregion

        public TimetableViewModel()
        {
            Timetable = new ObservableCollection<TimetableData>();
        }

        #region Methods
        public async Task<bool> AddAsync()
        {
            if (!string.IsNullOrWhiteSpace(Subject_Input) &&
                !string.IsNullOrWhiteSpace(Description_Input) &&
                !string.IsNullOrWhiteSpace(Lecture_Input) &&
                StartDateTime_Input != null &&
                EndDateTime_Input != null)
            {
                Timetable.Add(new TimetableData()
                {
                     Subject = Subject_Input,
                     Description = Description_Input,
                     Lecture = Lecture_Input,
                     StartDateTime = StartDateTime_Input,
                     EndDateTime = EndDateTime_Input
                });

                await WriteToFileAsync();
                return true;
            }
            else
            {
                return false;
            }
        }

        private async Task WriteToFileAsync()
        {
            string jsonString = JsonConvert.SerializeObject(Timetable);
            await new FileService().WriteDataToLocalStorageAsync(TIMETABLE_JSONFILENAME, jsonString);
        }

        public async Task<TimetableViewModel> LoadAsync()
        {
            try
            {
                var jsonString = await new FileService().ReadDataFromLocalStorageAsync(TIMETABLE_JSONFILENAME);
                Timetable = await JsonConvert.DeserializeObjectAsync<ObservableCollection<TimetableData>>(jsonString);
            }
            catch { }

            return this;
        }
        #endregion

        #region INotifyPropertyChanged Helper
        public event PropertyChangedEventHandler PropertyChanged;
        public void RaisePropertyChanged([CallerMemberName]string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public bool Set<T>(ref T storage, T value, [CallerMemberName]string propertyName = null)
        {
            if (Equals(storage,value))
            {
                return false;
            }
            storage = value;
            RaisePropertyChanged(propertyName);
            return true;
        }
        #endregion
    }

    #region Convertors
    public class DateTimeToDateTimeToDateTimeOffsetConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language) => new DateTimeOffset((DateTime)value);
        public object ConvertBack(object value, Type targetType, object parameter, string language) => ((DateTimeOffset)value).DateTime;
    }
    #endregion
}
