﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace StudentAlpha_Codes.Models
{
    public class TimetableData : INotifyPropertyChanged
    {
        private string _Subject;
        public string Subject
        {
            get { return _Subject; }
            set { Set(ref _Subject, value); }
        }

        private string _Description;
        public string Description
        {
            get { return _Description; }
            set { Set(ref _Description, value); }
        }

        private string _Lecture;
        public string Lecture
        {
            get { return _Lecture; }
            set { Set(ref _Lecture, value); }
        }

        private DateTime _StartDateTime;
        public DateTime StartDateTime
        {
            get { return _StartDateTime; }
            set { Set(ref _StartDateTime, value); }
        }

        private DateTime _EndDateTime;
        public DateTime EndDateTime
        {
            get { return _EndDateTime; }
            set { Set(ref _EndDateTime, value); }
        }


        #region INotifyPropertyChanged Helper
        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged([CallerMemberName]string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public bool Set<T>(ref T storage, T value, [CallerMemberName]string propertyName = null)
        {
            if (Equals(storage, value))
                return false;
            storage = value;
            RaisePropertyChanged(propertyName);
            return true;
        }
        #endregion
    }
}
