﻿using static StudentAlpha.App;
using Newtonsoft.Json;
using StudentAlpha.Models;
using StudentAlpha.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentAlpha.ViewModels
{
    public class HomeViewModel
    {
        #region Properties
        public ObservableCollection<Assignment> Home1 { get; set; }
        public ObservableCollection<TimetableData> Home2 { get; set; }
        public ObservableCollection<Assignment> Home1_temp { get; set; }
        public ObservableCollection<TimetableData> Home2_temp { get; set; }
        #endregion
        
        #region Methods
        public HomeViewModel()
        {
            Home1 = new ObservableCollection<Assignment>();
            Home2 = new ObservableCollection<TimetableData>();
        }

        public async Task<HomeViewModel> ReadData()
        {
            try
            {
                var jsonstring1 = await new FileService().ReadDataFromLocalStorageAsync(ASSIGNMENTS_JSONFILENAME);
                Home1_temp = JsonConvert.DeserializeObject<ObservableCollection<Assignment>>(jsonstring1);

                var jsonstring2 = await new FileService().ReadDataFromLocalStorageAsync(TIMETABLE_JSONFILENAME);
                Home2_temp = JsonConvert.DeserializeObject<ObservableCollection<TimetableData>>(jsonstring2);
            }
            catch {}
            return this;
        }

        DateTime today = DateTime.Now;
        TimeSpan today2 = DateTime.Now.TimeOfDay;

        public HomeViewModel Glance()
        {
            foreach (var item in Home1_temp)
            {
                if (item.DueDate == today)
                {
                    Home1.Add(item);
                }
            }

            foreach (var item2 in Home2_temp)
            {
                if (item2.StartTime == today2)
                {
                    Home2.Add(item2);
                }
            }  
            return this;
        }

        public async Task WriteData()
        {
            string jsonstring1 = JsonConvert.SerializeObject(Home1);
            string jsonstring2 = JsonConvert.SerializeObject(Home2);

            await new FileService().WriteDataToLocalStorageAsync("glance1.txt", jsonstring1);
            await new FileService().WriteDataToLocalStorageAsync("glance2.txt", jsonstring2);
        }
        #endregion
    }
}
